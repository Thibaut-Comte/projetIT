package com.ecetech.bti3.projetIT.ecole.scpi.common;

public class ConnectionDB {

}
